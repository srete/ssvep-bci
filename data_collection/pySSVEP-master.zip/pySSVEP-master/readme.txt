An attempt to create a SSVEP stimulus presentation program in Python using pygame.

Currently supports custom "flickies" (checkerboards) at four locations (left, right, top, bottom) on the screen.